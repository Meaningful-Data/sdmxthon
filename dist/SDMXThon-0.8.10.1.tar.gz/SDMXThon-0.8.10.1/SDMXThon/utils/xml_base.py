import os
import re as re_
import sys

from lxml import etree as etree_

Tag_pattern_ = re_.compile(r'({.*})?(.*)')
CDATA_pattern_ = re_.compile(r'<!\[CDATA\[.*?]]>', re_.DOTALL)
BaseStrType_ = str


#
# You can replace the following class definition by defining an
# importable module named "generatedscollector" containing a class
# named "GdsCollector".  See the default class definition below for
# clues about the possible content of that class.
#

def parse_xml(infile, parser=None, **kwargs):
    if parser is None:
        # Use the lxml ElementTree compatible parser so that, e.g.,
        #   we ignore comments.
        try:
            parser = etree_.ETCompatXMLParser()
        except AttributeError:
            # fallback to xml.etree
            parser = etree_.XMLParser()
    try:
        if isinstance(infile, os.PathLike):
            infile = os.path.join(infile)
    except AttributeError:
        pass
    doc = etree_.parse(infile, parser=parser, **kwargs)
    return doc


def find_attr_value_(attr_name, node):
    if isinstance(node, dict):
        if attr_name in node.keys():
            return node[attr_name]
        else:
            return None

    attrs = node.attrib
    if '}' in attr_name:
        attr_parts = attr_name.split('}')
        attr_parts[0] += '}'
    else:
        attr_parts = attr_name.split(':')
    value = None
    if len(attr_parts) == 1:
        value = attrs.get(attr_name)
    elif len(attr_parts) == 2:
        prefix, name = attr_parts
        if prefix == '{http://www.w3.org/XML/1998/namespace}':
            value = attrs.get(f'{prefix}{name}')
        else:
            namespace = node.nsmap.get(prefix)
            if namespace is not None:
                value = attrs.get(f'{prefix}:{name}')
    return value


def encode_str_2_3(instr):
    return instr


def raise_parse_error(node, msg):
    if node is not None:
        msg = f'{msg} (element {node.tag}/line {node.sourceline})'
    raise GDSParseError(msg)


def cast(typ, value):
    if typ is None or value is None:
        return value
    return typ(value)


def get_required_ns_prefix_defs(rootNode):
    """Get all name space prefix definitions required in this XML doc.
    Return a dictionary of definitions and a char string of definitions.
    """
    nsmap = {
        prefix: uri
        for node in rootNode.iter()
        for (prefix, uri) in node.nsmap.items()
        if prefix is not None
    }

    namespacedefs = ' '.join([f'xmlns:{prefix}="{uri}"' for prefix, uri in nsmap.items()])

    return nsmap, namespacedefs


def makeWarnings(print_warnings, gds_collector):
    if print_warnings and len(gds_collector.get_messages()) > 0:
        separator = ('-' * 50) + '\n'
        sys.stderr.write(separator)
        sys.stderr.write(f'----- Warnings -- count: {len(gds_collector.get_messages())} -----\n')
        gds_collector.write_messages(sys.stderr)
        sys.stderr.write(separator)


class GDSParseError(Exception):
    pass
