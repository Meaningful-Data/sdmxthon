ALLOWED_ERRORS_CONTENT = [
    'content type is empty',
    "The QName value",
    "The type definition is abstract."
]
